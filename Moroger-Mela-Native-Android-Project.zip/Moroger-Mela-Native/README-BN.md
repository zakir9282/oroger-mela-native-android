# মোরগের মেলা — Native Android project

এই প্রজেক্টটি Jetpack Compose দিয়ে তৈরি Native Android অ্যাপ; WebView ব্যবহার করে না।

## Build
- Android Studio-তে এই ফোল্ডার Open করুন।
- Gradle sync শেষ হলে Build > Build APK(s) নির্বাচন করুন।
- APK: `app/build/outputs/apk/debug/app-debug.apk`

## বর্তমান সংস্করণে থাকা কাজ
- ড্যাশবোর্ড
- চারটি পাখির আলাদা ক্রয় ও বিক্রয় বিভাগ
- জাতভিত্তিক তালিকা, যোগ/সম্পাদনা/মুছুন, অনুসন্ধান
- পা+মাথা ও ড্রেসিং ফি
- জাতভিত্তিক স্টক
- কর্মচারী, বেতন ও দৈনিক হাজিরা
- তারিখভিত্তিক সারাংশ ও রিপোর্ট শেয়ার
- ডিভাইসের app-private SharedPreferences-এ লোকাল ডেটা সংরক্ষণ

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি সম্পূর্ণ Web App parity নয়। AppDeploy secure email/Google authentication, server-side Admin/Super Admin approval, Google Drive OAuth backup/restore, Web App-এর PDF/Excel export-এর সমতুল্য ফাইল জেনারেশন, এবং আগের Web App-এর LocalStorage ডেটা migration এই ZIP-এ বাস্তবায়িত হয়নি। নিরাপত্তার কারণে এগুলোর বদলে কোনো ভুয়া স্থানীয় লগইন বা অ্যাডমিন অনুমতি তৈরি করা হয়নি। এই সংস্করণকে production-ready বা সম্পূর্ণ Web App replacement হিসেবে ব্যবহার করবেন না।
