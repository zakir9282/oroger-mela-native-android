package com.morogermela.app

import android.os.Bundle
import android.content.Context
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF236B42)
private val DarkGreen = Color(0xFF123C29)
private val Pale = Color(0xFFF1F6F2)
private val birds = listOf("মুরগি", "হাঁস", "কবুতর", "কোয়েল")
private val breeds = mapOf(
    "মুরগি" to listOf("ব্রাউন/কক", "সোনালি", "ব্রয়লার", "লেয়ার", "দেশি"),
    "হাঁস" to listOf("খাকি ক্যাম্পবেল", "ইন্ডিয়ান রানার", "দেশি হাঁস"),
    "কোয়েল" to listOf("দেশি", "জাপানি কোয়েল", "ব্রাউন কোয়েল"),
    "কবুতর" to listOf("গিরিবাজ", "লাহোরি", "দেশি কবুতর")
)
private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun taka(v: Double) = "৳ " + String.format(Locale.US, "%,.0f", v)

data class Entry(
    val id: String, val bird: String, val breed: String, val date: String,
    val qty: Double, val weight: Double, val rate: Double, val amount: Double, val supplier: String
)
data class OtherEntry(val id: String, val date: String, val quantity: Double, val amount: Double)
data class Staff(val id: String, val name: String, val joining: String, val salary: Double, val attendance: Set<String>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MorogerMela() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MorogerMela() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("moroger_mela_data", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("home") }
    var bird by remember { mutableStateOf("মুরগি") }
    var breed by remember { mutableStateOf(breeds.getValue("মুরগি").first()) }
    var birdSelected by remember { mutableStateOf(false) }
    var stockBird by remember { mutableStateOf("মুরগি") }
    var stockOther by remember { mutableStateOf(false) }
    var purchases by remember { mutableStateOf(loadEntries(prefs, "purchases")) }
    var sales by remember { mutableStateOf(loadEntries(prefs, "sales")) }
    var feet by remember { mutableStateOf(loadOthers(prefs, "feet")) }
    var dressing by remember { mutableStateOf(loadOthers(prefs, "dressing")) }
    var staff by remember { mutableStateOf(loadStaff(prefs)) }
    var showDialog by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf<String?>(null) }
    var date by remember { mutableStateOf(today()) }
    var qty by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }
    var personName by remember { mutableStateOf("") }
    var salary by remember { mutableStateOf("") }
    var joining by remember { mutableStateOf(today()) }
    var otherQty by remember { mutableStateOf("") }
    var otherAmount by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }

    fun persist() {
        prefs.edit()
            .putString("purchases", entriesJson(purchases).toString())
            .putString("sales", entriesJson(sales).toString())
            .putString("feet", othersJson(feet).toString())
            .putString("dressing", othersJson(dressing).toString())
            .putString("staff", staffJson(staff).toString()).apply()
    }
    fun resetForm() {
        editId = null; date = today(); qty = ""; weight = ""; rate = ""; amount = ""
        supplier = ""; otherQty = ""; otherAmount = ""; personName = ""; salary = ""; joining = today(); error = ""
    }
    fun openEntry(kind: String, row: Entry? = null) {
        resetForm()
        showDialog = kind
        if (row != null) {
            editId = row.id; date = row.date; qty = row.qty.toString(); weight = row.weight.toString()
            rate = row.rate.toString(); amount = row.amount.toString(); supplier = row.supplier; breed = row.breed
        }
    }
    fun openOther(kind: String, row: OtherEntry? = null) {
        resetForm(); showDialog = kind
        if (row != null) { editId = row.id; date = row.date; otherQty = row.quantity.toString(); otherAmount = row.amount.toString() }
    }
    fun openStaff(row: Staff? = null) {
        resetForm(); showDialog = "staff"
        if (row != null) { editId = row.id; personName = row.name; salary = row.salary.toString(); joining = row.joining }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = DarkGreen, background = Pale)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("মোরগের মেলা", fontWeight = FontWeight.Bold, color = DarkGreen); Text("আপনার হিসাব, আপনার নিয়ন্ত্রণে", fontSize = 11.sp, color = Color.Gray) } },
                    navigationIcon = { if (page != "home") IconButton(onClick = { if ((page == "purchase" || page == "sales") && birdSelected) birdSelected = false else { page = "home"; birdSelected = false } }) { Icon(Icons.Default.ArrowBack, "ফিরুন") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            containerColor = Pale
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 14.dp)) {
                when (page) {
                    "home" -> HomePage { page = it; birdSelected = false }
                    "purchase", "sales" -> {
                        if (!birdSelected) {
                            Text(if (page == "purchase") "ক্রয়ের পাখি নির্বাচন" else "বিক্রয়ের পাখি নির্বাচন", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DarkGreen, modifier = Modifier.padding(vertical = 14.dp))
                            Text("যে পাখির হিসাব করবেন, সেটি নির্বাচন করুন।", color = Color.Gray)
                            birds.forEach { type ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { bird = type; breed = breeds.getValue(type).first(); birdSelected = true }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Pets, null, tint = Green); Spacer(Modifier.width(14.dp))
                                        Text(type, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                        Icon(Icons.Default.ChevronRight, null, tint = Green)
                                    }
                                }
                            }
                        } else {
                            Text("$bird · ${if (page == "purchase") "ক্রয়" else "বিক্রয়"}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DarkGreen, modifier = Modifier.padding(vertical = 10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                breeds.getValue(bird).forEach { b ->
                                    FilterChip(selected = breed == b, onClick = { breed = b }, label = { Text(b, fontSize = 11.sp) })
                                }
                            }
                            Button(onClick = { openEntry(page) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text(" $bird যোগ") }
                            OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), placeholder = { Text("জাত, তারিখ বা নাম খুঁজুন") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                            val source = if (page == "purchase") purchases else sales
                            val rows = source.filter { it.bird == bird && it.breed == breed && (it.date + it.supplier + it.breed).contains(search, true) }
                            if (rows.isEmpty()) EmptyText()
                            LazyColumn { items(rows, key = { it.id }) { row ->
                                EntryCard(row, page == "purchase", { openEntry(page, row) }, {
                                    if (page == "purchase") purchases = purchases.filterNot { it.id == row.id } else sales = sales.filterNot { it.id == row.id }
                                    persist()
                                })
                            } }
                            Text("মোট: ${taka(rows.sumOf { it.amount })}", fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.padding(10.dp))
                        }
                    }
                    "other" -> {
                        Text("অন্যান্য হিসাব", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DarkGreen, modifier = Modifier.padding(vertical = 12.dp))
                        OtherSection("পা+মাথা", feet, { openOther("feet") }, { openOther("feet", it) }, { row -> feet = feet.filterNot { it.id == row.id }; persist() })
                        OtherSection("ড্রেসিং ফি", dressing, { openOther("dressing") }, { openOther("dressing", it) }, { row -> dressing = dressing.filterNot { it.id == row.id }; persist() })
                    }
                    "stock" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FilterChip(selected = !stockOther, onClick = { stockOther = false }, label = { Text("পাখির স্টক") })
                            Spacer(Modifier.width(8.dp)); FilterChip(selected = stockOther, onClick = { stockOther = true }, label = { Text("অন্যান্য হিসাব") })
                        }
                        if (!stockOther) {
                            birds.forEach { FilterChip(selected = stockBird == it, onClick = { stockBird = it }, label = { Text(it) }) }
                            breeds.getValue(stockBird).forEach { b ->
                                val bought = purchases.filter { it.bird == stockBird && it.breed == b }.sumOf { it.qty }
                                val sold = sales.filter { it.bird == stockBird && it.breed == b }.sumOf { it.qty }
                                val cost = purchases.filter { it.bird == stockBird && it.breed == b }.sumOf { it.amount }
                                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(b, fontWeight = FontWeight.Bold)
                                        Text("ক্রয়: $bought   বিক্রয়: $sold   অবশিষ্ট: ${bought - sold}")
                                        Text("গড় ক্রয়মূল্য: ${taka(if (bought > 0) cost / bought else 0.0)}", color = Green)
                                        if (sold > bought) Text("সতর্কতা: বিক্রয়ের সংখ্যা ক্রয়ের চেয়ে বেশি হয়েছে।", color = Color.Red)
                                    }
                                }
                            }
                        } else {
                            Text("পা+মাথা মোট: ${taka(feet.sumOf { it.amount })}")
                            Text("ড্রেসিং ফি মোট: ${taka(dressing.sumOf { it.amount })}")
                            Text("সর্বমোট: ${taka(feet.sumOf { it.amount } + dressing.sumOf { it.amount })}", fontWeight = FontWeight.Bold)
                        }
                    }
                    "staff" -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("কর্মীদের তালিকা ও হাজিরা", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Button(onClick = { openStaff() }) { Icon(Icons.Default.Add, null); Text("স্টাফ যোগ") }
                        }
                        LazyColumn { items(staff, key = { it.id }) { s ->
                            var present by remember(s.id, s.attendance) { mutableStateOf(today() in s.attendance) }
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(s.name, fontWeight = FontWeight.Bold)
                                    Text("যোগদান: ${s.joining} · মাসিক বেতন: ${taka(s.salary)}")
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(onClick = {
                                            present = !present
                                            staff = staff.map { if (it.id == s.id) it.copy(attendance = if (present) it.attendance + today() else it.attendance - today()) else it }
                                            persist()
                                        }) { Text(if (present) "উপস্থিত" else "অনুপস্থিত") }
                                        Spacer(Modifier.weight(1f))
                                        TextButton(onClick = { openStaff(s) }) { Text("সম্পাদনা") }
                                        TextButton(onClick = { staff = staff.filterNot { it.id == s.id }; persist() }) { Text("মুছুন", color = Color.Red) }
                                    }
                                }
                            }
                        } }
                    }
                    "reports" -> {
                        Text("রিপোর্ট", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                        OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { Text("তারিখ (YYYY-MM-DD)") })
                        val bought = purchases.filter { it.date == date }.sumOf { it.amount }
                        val sold = sales.filter { it.date == date }.sumOf { it.amount }
                        val other = feet.filter { it.date == date }.sumOf { it.amount } + dressing.filter { it.date == date }.sumOf { it.amount }
                        ReportLine("মোট ক্রয়", bought); ReportLine("মোট বিক্রয়", sold); ReportLine("পা+মাথা ও ড্রেসিং", other)
                        ReportLine("আনুমানিক লাভ/লোকসান", sold - bought, true)
                        Button(onClick = { shareReport(context, date, purchases, sales, feet, dressing, staff) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text(" রিপোর্ট শেয়ার / Excel-এ খুলুন") }
                    }
                    "settings" -> {
                        Text("সেটিংস", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("ডেভেলপার তথ্য", fontWeight = FontWeight.Bold)
                                Text("মোঃ আনিসুর রহমান চৌধুরী")
                                Text("আমি মো. আনিসুর রহমান চৌধুরী। প্রযুক্তি ও কোডিংয়ের পাশাপাশি নতুন নতুন জায়গায় ঘুরাঘুরি করতে আমি ভীষণ ভালোবাসি। প্রযুক্তির ছোঁয়ায় মানুষের দৈনন্দিন জীবনকে আরও সহজ ও নিরাপদ করার লক্ষ্য নিয়েই এই অ্যাপসটি তৈরি করেছি।")
                                Text("WhatsApp: 01307658870\nEmail: martamim016@gmail.com\nTelegram: @tamim_2109")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { page = "privacy" }, modifier = Modifier.fillMaxWidth()) { Text("প্রাইভেসি নীতি") }
                    }
                    "privacy" -> {
                        Text("প্রাইভেসি নীতি", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                        Text("এই Native সংস্করণে আপনার হিসাব এই ডিভাইসের অ্যাপ-স্টোরেজে রাখা হয়। অ্যাপের ডেটা অন্য ডিভাইসে স্বয়ংক্রিয়ভাবে যায় না। অ্যাপের ডেটা নিরাপদ রাখতে ডিভাইস লক ব্যবহার করুন এবং অ্যাপ আনইনস্টল করার আগে প্রয়োজনীয় তথ্য সংরক্ষণ করুন।", modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
    }

    if (showDialog.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { showDialog = ""; error = "" },
            title = { Text(when(showDialog) { "purchase" -> "ক্রয় তথ্য · $bird"; "sales" -> "বিক্রয় তথ্য · $bird"; "feet" -> "পা+মাথা বিক্রির তথ্য"; "dressing" -> "কাস্টমারের ড্রেসিং ফি"; else -> "স্টাফের তথ্য" }) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (showDialog == "purchase" || showDialog == "sales") {
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                            OutlinedTextField(breed, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("জাত") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                breeds.getValue(bird).forEach { b -> DropdownMenuItem(text = { Text(b) }, onClick = { breed = b; expanded = false }) }
                            }
                        }
                        Field("তারিখ", date, { date = it })
                        Field("সংখ্যা", qty, { qty = it; if (bird == "কোয়েল" || bird == "কবুতর") amount = ((it.toDoubleOrNull() ?: 0.0) * (rate.toDoubleOrNull() ?: 0.0)).toString() }, true)
                        if (bird == "মুরগি" || bird == "হাঁস") {
                            Field("ওজন (কেজি)", weight, { weight = it; amount = ((it.toDoubleOrNull() ?: 0.0) * (rate.toDoubleOrNull() ?: 0.0)).toString() }, true)
                            Field("দর (প্রতি কেজি)", rate, { rate = it; amount = ((weight.toDoubleOrNull() ?: 0.0) * (it.toDoubleOrNull() ?: 0.0)).toString() }, true)
                        } else {
                            Field("দর (প্রতি পিস)", rate, { rate = it; amount = ((qty.toDoubleOrNull() ?: 0.0) * (it.toDoubleOrNull() ?: 0.0)).toString() }, true)
                        }
                        if (showDialog == "purchase") Field("সরবরাহকারীর নাম", supplier, { supplier = it })
                        Field("মোট টাকা", amount, { amount = it }, true)
                    } else if (showDialog == "staff") {
                        Field("কর্মীর নাম", personName, { personName = it })
                        Field("যোগদানের তারিখ", joining, { joining = it })
                        Field("মাসিক বেতন (টাকা)", salary, { salary = it }, true)
                    } else {
                        Field("তারিখ", date, { date = it })
                        Field(if (showDialog == "feet") "কেজি+পিছ" else "সংখ্যা", otherQty, { otherQty = it }, true)
                        Field("টাকা", otherAmount, { otherAmount = it }, true)
                    }
                    if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (showDialog == "purchase" || showDialog == "sales") {
                        val q = qty.toDoubleOrNull(); val a = amount.toDoubleOrNull()
                        if (q == null || q <= 0 || a == null || a <= 0 || (showDialog == "purchase" && supplier.isBlank())) {
                            error = "তারিখ, সংখ্যা, টাকা এবং ক্রয়ের ক্ষেত্রে সরবরাহকারীর নাম দিন।"
                        } else {
                            val row = Entry(editId ?: System.currentTimeMillis().toString(), bird, breed, date, q, weight.toDoubleOrNull() ?: 0.0, rate.toDoubleOrNull() ?: 0.0, a, supplier)
                            val list = if (showDialog == "purchase") purchases else sales
                            val updated = if (editId == null) listOf(row) + list else list.map { if (it.id == editId) row else it }
                            if (showDialog == "purchase") purchases = updated else sales = updated
                            persist(); showDialog = ""
                        }
                    } else if (showDialog == "staff") {
                        val sal = salary.toDoubleOrNull()
                        if (personName.isBlank() || sal == null || sal < 0) error = "কর্মীর নাম ও সঠিক বেতন লিখুন।"
                        else {
                            val row = Staff(editId ?: System.currentTimeMillis().toString(), personName, joining, sal, staff.firstOrNull { it.id == editId }?.attendance ?: emptySet())
                            staff = if (editId == null) listOf(row) + staff else staff.map { if (it.id == editId) row else it }
                            persist(); showDialog = ""
                        }
                    } else {
                        val q = otherQty.toDoubleOrNull(); val a = otherAmount.toDoubleOrNull()
                        if (q == null || q <= 0 || a == null || a < 0) error = "পরিমাণ ও সঠিক টাকা লিখুন।"
                        else {
                            val row = OtherEntry(editId ?: System.currentTimeMillis().toString(), date, q, a)
                            val list = if (showDialog == "feet") feet else dressing
                            val updated = if (editId == null) listOf(row) + list else list.map { if (it.id == editId) row else it }
                            if (showDialog == "feet") feet = updated else dressing = updated
                            persist(); showDialog = ""
                        }
                    }
                }) { Text("সংরক্ষণ") }
            },
            dismissButton = { TextButton(onClick = { showDialog = "" }) { Text("বাতিল") } }
        )
    }
}

@Composable
private fun HomePage(open: (String) -> Unit) {
    val cards = listOf(
        Triple("ক্রয় হিসাব", "পাখি ক্রয়ের হিসাব", "purchase"),
        Triple("বিক্রয় হিসাব", "পাখি বিক্রয়ের হিসাব", "sales"),
        Triple("অন্যান্য হিসাব", "পা+মাথা ও ড্রেসিং ফি", "other"),
        Triple("স্টক হিসাব", "জাতভিত্তিক মজুত", "stock"),
        Triple("কর্মচারী", "কর্মী, হাজিরা ও বেতন", "staff"),
        Triple("রিপোর্ট", "দৈনিক হিসাব ও সারাংশ", "reports"),
        Triple("সেটিংস", "প্রোফাইল ও তথ্য", "settings")
    )
    LazyColumn(contentPadding = PaddingValues(vertical = 14.dp)) {
        item { Text("ড্যাশবোর্ড", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = DarkGreen); Spacer(Modifier.height(10.dp)) }
        items(cards) { c ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { open(c.third) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Folder, null, tint = Green, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) { Text(c.first, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = DarkGreen); Text(c.second, color = Color.Gray, fontSize = 12.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = Green)
                }
            }
        }
    }
}
@Composable private fun Field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text))
}
@Composable private fun EmptyText() { Box(Modifier.fillMaxWidth().padding(25.dp), contentAlignment = Alignment.Center) { Text("আপনি এখনো তথ্য যোগ করেননি", color = Color.Gray) } }
@Composable private fun EntryCard(row: Entry, purchase: Boolean, edit: () -> Unit, delete: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Text("${row.breed} · ${row.date}", fontWeight = FontWeight.Bold)
            Text("সংখ্যা: ${row.qty} · ওজন: ${row.weight} কেজি · দর: ${taka(row.rate)}")
            if (purchase && row.supplier.isNotBlank()) Text("সরবরাহকারী: ${row.supplier}")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(taka(row.amount), color = Green, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = edit) { Text("সম্পাদনা") }
                TextButton(onClick = delete) { Text("মুছুন", color = Color.Red) }
            }
        }
    }
}
@Composable private fun OtherSection(title: String, rows: List<OtherEntry>, add: () -> Unit, edit: (OtherEntry) -> Unit, delete: (OtherEntry) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Button(onClick = add) { Text("হিসাব যোগ") } }
        if (rows.isEmpty()) EmptyText()
        rows.forEach { row ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(row.date); Text("পরিমাণ: ${row.quantity} · ${taka(row.amount)}") }
                    TextButton(onClick = { edit(row) }) { Text("সম্পাদনা") }
                    TextButton(onClick = { delete(row) }) { Text("মুছুন", color = Color.Red) }
                }
            }
        }
        Text("মোট: ${taka(rows.sumOf { it.amount })}", fontWeight = FontWeight.Bold, color = Green)
    }
}
@Composable private fun ReportLine(label: String, value: Double, strong: Boolean = false) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal)
            Text(taka(value), color = if (strong) Green else DarkGreen, fontWeight = FontWeight.Bold)
        }
    }
}
private fun loadEntries(p: android.content.SharedPreferences, key: String): List<Entry> = try {
    val a = JSONArray(p.getString(key, "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { Entry(it.optString("id"), it.optString("bird"), it.optString("breed"), it.optString("date"), it.optDouble("qty"), it.optDouble("weight"), it.optDouble("rate"), it.optDouble("amount"), it.optString("supplier")) } }
} catch (_: Exception) { emptyList() }
private fun entriesJson(rows: List<Entry>) = JSONArray().apply { rows.forEach { put(JSONObject().put("id",it.id).put("bird",it.bird).put("breed",it.breed).put("date",it.date).put("qty",it.qty).put("weight",it.weight).put("rate",it.rate).put("amount",it.amount).put("supplier",it.supplier)) } }
private fun loadOthers(p: android.content.SharedPreferences, key: String): List<OtherEntry> = try {
    val a = JSONArray(p.getString(key, "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { OtherEntry(it.optString("id"), it.optString("date"), it.optDouble("quantity"), it.optDouble("amount")) } }
} catch (_: Exception) { emptyList() }
private fun othersJson(rows: List<OtherEntry>) = JSONArray().apply { rows.forEach { put(JSONObject().put("id",it.id).put("date",it.date).put("quantity",it.quantity).put("amount",it.amount)) } }
private fun loadStaff(p: android.content.SharedPreferences): List<Staff> = try {
    val a = JSONArray(p.getString("staff", "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
        val at = o.optJSONArray("attendance") ?: JSONArray()
        Staff(o.optString("id"), o.optString("name"), o.optString("joining"), o.optDouble("salary"), (0 until at.length()).map { at.getString(it) }.toSet())
    } }
} catch (_: Exception) { emptyList() }
private fun staffJson(rows: List<Staff>) = JSONArray().apply { rows.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("joining",it.joining).put("salary",it.salary).put("attendance", JSONArray(it.attendance.toList()))) } }
private fun shareReport(context: Context, date: String, p: List<Entry>, s: List<Entry>, f: List<OtherEntry>, d: List<OtherEntry>, staff: List<Staff>) {
    val text = buildString {
        appendLine("মোরগের মেলা রিপোর্ট"); appendLine("তারিখ: $date")
        appendLine("ক্রয়: ${taka(p.filter { it.date == date }.sumOf { it.amount })}")
        appendLine("বিক্রয়: ${taka(s.filter { it.date == date }.sumOf { it.amount })}")
        appendLine("পা+মাথা: ${taka(f.filter { it.date == date }.sumOf { it.amount })}")
        appendLine("ড্রেসিং ফি: ${taka(d.filter { it.date == date }.sumOf { it.amount })}")
        appendLine("কর্মী: ${staff.size} জন")
    }
    val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "মোরগের মেলা রিপোর্ট $date").putExtra(Intent.EXTRA_TEXT, text)
    context.startActivity(Intent.createChooser(intent, "রিপোর্ট শেয়ার করুন"))
}
